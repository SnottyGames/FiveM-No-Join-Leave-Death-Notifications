fx_version 'cerulean'
game 'gta5'

author 'Snotty'
description 'Removes all join, leave, and death notifications'
version '1.0.0'

client_script 'client.lua'
